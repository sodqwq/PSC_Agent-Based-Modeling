package khModel;

import java.awt.Color;
import spaces.Spaces;
import sweep.GUIStateSweep;
import sweep.SimStateSweep;

public class AgentsGUI extends GUIStateSweep {
	public AgentsGUI(SimStateSweep state, int gridWidth, int gridHeight, Color backdrop, Color agentDefaultColor,
			boolean agentPortrayal) {
		super(state, gridWidth, gridHeight, backdrop, agentDefaultColor, agentPortrayal);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// AgentsGUI.initialize(Environment.class,Experimenter.class, AgentsGUI.class, 600, 600, Color.WHITE, Color.BLUE, false, Spaces.SPARSE);
		String[] title = {"Couple Correlation", "Mean Attractiveness"};
		// A string array, where every entry is the title of a chart
		String[] x = {"Dates", "Dates"};
		// A string array, where every entry is the x-axis title
		String[] y = {"Correlation", "Attractiveness"};
		// A string array, where every entry is the y-axis title
		AgentsGUI.initializeArrayTimeSeriesChart(2, title, x, y);
		// Creates as many charts as indicated by the first number
		// All arrays must have same number of elements as the number of charts
		String[] titleH = {"Attractiveness Distribution"}; //chart title
		String[] xH = {"Attractiveness"}; //x-axis label
		String[] yH = {"Number of Agents"}; //y-axis label
		int[] bins = {10}; // number of attractiveness ranks
		AgentsGUI.initializeArrayHistogramChart(1, titleH, xH, yH, bins);
		AgentsGUI.initialize(Environment.class, Experimenter.class, AgentsGUI.class, 400, 400, Color.WHITE, Color.blue, false, Spaces.SPARSE);
 	}

}
